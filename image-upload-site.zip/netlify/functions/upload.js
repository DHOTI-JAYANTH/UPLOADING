const AWS = require("aws-sdk");
const multiparty = require("multiparty");
const fs = require("fs");

const s3 = new AWS.S3({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: "us-east-1", // Change based on your region
});

exports.handler = async (event) => {
    const form = new multiparty.Form();

    return new Promise((resolve) => {
        form.parse(event, async (error, fields, files) => {
            if (error) return resolve({ statusCode: 500, body: "Error parsing form" });

            const whatsapp = fields.whatsapp[0];
            const file = files.image[0];

            if (file.size > 25 * 1024 * 1024) {
                return resolve({ statusCode: 400, body: "File size must be under 25 MB." });
            }

            const params = {
                Bucket: process.env.S3_BUCKET_NAME,
                Key: `uploads/${file.originalFilename}`,
                Body: fs.createReadStream(file.path),
                ContentType: file.headers["content-type"],
            };

            try {
                const data = await s3.upload(params).promise();
                resolve({ statusCode: 200, body: `Image uploaded successfully: ${data.Location}` });
            } catch (uploadError) {
                resolve({ statusCode: 500, body: "Error uploading to S3" });
            }
        });
    });
};