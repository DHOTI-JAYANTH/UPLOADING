document.getElementById("uploadForm").onsubmit = async (e) => {
    e.preventDefault();

    const image = document.getElementById("image").files[0];
    const whatsapp = document.getElementById("whatsapp").value;
    const messageElement = document.getElementById("message");

    if (image.size > 25 * 1024 * 1024) {
        messageElement.textContent = "Image must be under 25 MB.";
        return;
    }

    const formData = new FormData();
    formData.append("image", image);
    formData.append("whatsapp", whatsapp);

    try {
        const response = await fetch("/.netlify/functions/upload", {
            method: "POST",
            body: formData,
        });
        const result = await response.text();
        messageElement.textContent = result;
    } catch (error) {
        messageElement.textContent = "Error uploading image.";
    }
};